from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches



#-----------------------------------------------------------------
#PRODS MAS Y MENOS VENDIDOS/BUSCADOS POR PRODUCTO

#Listas para la división de los productos por ventas y búsquedas en tres(más menos y no vendidos/buscados:
productos_mas_vendidos = []
productos_mas_buscados = []
productos_menos_vendidos = []
productos_menos_buscados = []
productos_no_buscados = []
productos_rezagados = [] #Corresponde a los productos no vendidos

#Listas para almacenar todos los productos vendidos y luego ordenarlos
total_productos_vendidos = []
total_productos_buscados = []
total_prods_vendidos_ordenados = []
total_prods_buscados_ordenados = []

#Para sacar los productos más y menos vendidos
contador = 0

for product in lifestore_products: #Busca dentro de todos los productos
  for product_sold in lifestore_sales: #Busca dentro de todas las búsquedas
    if product[0]== product_sold[1]: #Compara IDs de producto
      contador += 1 #Suma una venta
  total_prods_vendidos_formato = [product[0], contador] #Formato ideal
  total_productos_vendidos.append(total_prods_vendidos_formato) #Agrega todos los productos vendidos a la lista
  contador = 0

#Ordeno la lista total_productos_vendidos:
while total_productos_vendidos: #Mientras existan productos en la lista
  minimo_ventas = total_productos_vendidos[0][1] #El mínimi inicial va a ser el primer valor de venta
  lista_actual = total_productos_vendidos[0]
  for product_sold_formato in total_productos_vendidos:
    if product_sold_formato[1] < minimo_ventas: #Verifica si es menor al mínimo
      minimo_ventas = product_sold_formato[1] #Si es menor se vuelve el nuevo mínimo
      lista_actual = product_sold_formato 
  total_prods_vendidos_ordenados.append(lista_actual) #Agrega la lista actual
  total_productos_vendidos.remove(lista_actual) #Elimina la lista actual

suma_ventas = 0 #Variable para ir sumando las ventas totales de todos los productos
n_ventas = 0 #Para ir contando el numero de productos vendidos

#Promedio de ventas (excluyendo los productos no vendidos):
for producto_vendido in total_prods_vendidos_ordenados:
  if producto_vendido[1] != 0: #Excluye los productos con 0 ventas ya que no se tomarán en cuenta para el promedio
    num_ventas = int(producto_vendido[1]) #Estoy casi segura de que ya era un int pero por si las dudas lo pasamos a número 
    suma_ventas += num_ventas
    n_ventas += 1

promedio_ventas = suma_ventas/n_ventas #Sacamos el promedio de las ventas para poder dividir los productos en más y menos vendidos

#Saco más, menos y no vendidos
for producto_vendido in total_prods_vendidos_ordenados:
  if producto_vendido[1] >= promedio_ventas: #Compara si está arriba del promedio para agregar el producto a la lista correspondiente
    productos_mas_vendidos.append(producto_vendido)
  elif producto_vendido[1] == 0:
   productos_rezagados.append(producto_vendido)
  else:
    productos_menos_vendidos.append(producto_vendido)

#Sacar los productos más y menos buscados:
contador = 0
#Mismo pordecimiento que para los más y menos vendidos pero usando la lista de búsquedas
for product in lifestore_products:
  for product_searched in lifestore_searches:
    if product[0]== product_searched[1]:
      contador += 1
  total_prods_buscados_formato = [product[0], contador]
  total_productos_buscados.append(total_prods_buscados_formato)
  contador = 0

#Ordeno la lista total_productos_buscados:
while total_productos_buscados:
  minimo_busqueda = total_productos_buscados[0][1]
  lista_actual = total_productos_buscados[0]
  for product_searched_formato in total_productos_buscados:
    if product_searched_formato[1] < minimo_busqueda:
      minimo_busqueda = product_searched_formato[1]
      lista_actual = product_searched_formato
  total_prods_buscados_ordenados.append(lista_actual)
  total_productos_buscados.remove(lista_actual)

suma_busquedas = 0
n_busquedas = 0

#Promedio de búsqueda:
for producto_buscado in total_prods_buscados_ordenados:
  if producto_buscado[1] != 0:
    num_busquedas = int(producto_buscado[1])
    suma_busquedas += num_busquedas
    n_busquedas += 1

promedio_busquedas = suma_busquedas/n_busquedas

#Las búsquedas más altas serán las que se encuentren por arriba del promedio
#Saco más, menos y no buscados
for producto_buscado in total_prods_buscados_ordenados:
  if producto_buscado[1] > promedio_busquedas: #Comparo con promedio de búsquedas
    productos_mas_buscados.append(producto_buscado)
  elif producto_buscado[1] == 0:
   productos_no_buscados.append(producto_buscado)
  else:
    productos_menos_buscados.append(producto_buscado)



#-----------------------------------------------------------------
#PRODS MAS Y MENOS VENDIDOS/BUSCADOS POR CATEGORÍA

#Primero saco los más vendidos
#"c" es para indicar categoría de productos

c_procesadores =[] 
c_tarjetas_de_video =[] 
c_tarjetas_madre =[] 
c_discos_duros = []
c_memorias_usb = []
c_pantallas =[] 
c_bocinas =[] 
c_audifonos =[] 

#División de todos los productos por categorías:
for product_sold in total_prods_vendidos_ordenados:
  for product in lifestore_products:
    if product[0] == product_sold[0]: #Compara IDs
      categoria_actual = product[3] 
      if categoria_actual == "procesadores": #Verifica si la categoría corresponde o pasa al siguiente y así sucesivamente
        formato_ideal = [product[0], product_sold[1]] #Formato de ID, número de ventas totales del producto
        c_procesadores.append(formato_ideal) #Agrega a la lista de la categoría correspondiente
      elif categoria_actual == "tarjetas de video":
        formato_ideal = [product[0], product_sold[1]]
        c_tarjetas_de_video.append(formato_ideal)
      elif categoria_actual == "tarjetas madre":
        formato_ideal = [product[0], product_sold[1]]
        c_tarjetas_madre.append(formato_ideal)
      elif categoria_actual == "discos duros":
        formato_ideal = [product[0], product_sold[1]]
        c_discos_duros.append(formato_ideal)
      elif categoria_actual == "memorias usb":
        formato_ideal = [product[0], product_sold[1]]
        c_memorias_usb.append(formato_ideal)
      elif categoria_actual == "pantallas":
        formato_ideal = [product[0], product_sold[1]]
        c_pantallas.append(formato_ideal)
      elif categoria_actual == "bocinas":
        formato_ideal = [product[0], product_sold[1]]
        c_bocinas.append(formato_ideal)
      else:
        formato_ideal = [product[0], product_sold[1]]
        c_audifonos.append(formato_ideal)


#Siguiente paso: División de cada categoría en más, menos y no vendidos
c_suma_ventas = 0
n_ventas = 0

#Listas de procesadores
procesadores_mas_vendidos = []
procesadores_menos_vendidos = []
procesadores_no_vendidos = []

#Sumo las ventas y el total de productos en la categoría para poder sacar el promedio
for procesador in c_procesadores:
  venta_actual = procesador[1] 
  c_suma_ventas += venta_actual #Las ventas totales del producto se suman al total de la categoría
  if procesador[1] != 0: #Para el promedio excluyo los productos no vendidos
    n_ventas += 1 #Va sumando una venta

promedio_procesadores = c_suma_ventas / n_ventas

for producto_categorizado in c_procesadores:
  if producto_categorizado[1] >= promedio_procesadores: #Verifico si es igual o superior al promedio
    procesadores_mas_vendidos.append(producto_categorizado)
  elif producto_categorizado[1] == 0: #Productos no vendidos
    procesadores_no_vendidos.append(producto_categorizado)
  else: #En caso de que sea inferior al promedio
    procesadores_menos_vendidos.append(producto_categorizado)

#Para todas las categorías siguientes se sigue el mismo procedimiento que arriba
c_suma_ventas = 0 #Se resetean los dos contadores a 0
n_ventas = 0

#Tarjetas de video
tarjetas_video_mas_vendidos = []
tarjetas_video_menos_vendidos = []
tarjetas_video_no_vendidos = []

for tarjeta_video in c_tarjetas_de_video:
  venta_actual = tarjeta_video[1]
  c_suma_ventas += venta_actual
  if tarjeta_video[1] != 0:
    n_ventas += 1

promedio_tarjetas_video = c_suma_ventas / n_ventas

for producto_categorizado in c_tarjetas_de_video:
  if producto_categorizado[1] >= promedio_tarjetas_video:
    tarjetas_video_mas_vendidos.append(producto_categorizado)
  elif producto_categorizado[1] == 0:
    tarjetas_video_no_vendidos.append(producto_categorizado)
  else:
    tarjetas_video_menos_vendidos.append(producto_categorizado)

#Tarjetas madre
c_suma_ventas = 0
n_ventas = 0

tarjetas_madre_mas_vendidos = []
tarjetas_madre_menos_vendidos = []
tarjetas_madre_no_vendidos = []

for tarjeta_madre in c_tarjetas_madre:
  venta_actual = tarjeta_madre[1]
  c_suma_ventas += venta_actual
  if tarjeta_madre[1] != 0:
    n_ventas += 1

promedio_tarjetas_madre = c_suma_ventas / n_ventas

for producto_categorizado in c_tarjetas_madre:
  if producto_categorizado[1] >= promedio_tarjetas_madre:
    tarjetas_madre_mas_vendidos.append(producto_categorizado)
  elif producto_categorizado[1] == 0:
    tarjetas_madre_no_vendidos.append(producto_categorizado)
  else:
    tarjetas_madre_menos_vendidos.append(producto_categorizado)

#Discos duros
c_suma_ventas = 0
n_ventas = 0

discos_duros_mas_vendidos = []
discos_duros_menos_vendidos = []
discos_duros_no_vendidos = []

for disco_duro in c_discos_duros:
  venta_actual = disco_duro[1]
  c_suma_ventas += venta_actual
  if disco_duro[1] != 0:
    n_ventas += 1

promedio_discos_duros = c_suma_ventas / n_ventas

for producto_categorizado in c_discos_duros:
  if producto_categorizado[1] >= promedio_discos_duros:
    discos_duros_mas_vendidos.append(producto_categorizado)
  elif producto_categorizado[1] == 0:
    discos_duros_no_vendidos.append(producto_categorizado)
  else:
    discos_duros_menos_vendidos.append(producto_categorizado)

#Memorias usb
c_suma_ventas = 0
n_ventas = 0

memorias_usb_mas_vendidos = []
memorias_usb_menos_vendidos = []
memorias_usb_no_vendidos = []

for memoria_usb in c_memorias_usb:
  venta_actual = memoria_usb[1]
  c_suma_ventas += venta_actual
  if memoria_usb[1] != 0:
    n_ventas += 1

promedio_memorias_usb = c_suma_ventas / n_ventas

for producto_categorizado in c_memorias_usb:
  if producto_categorizado[1] >= promedio_memorias_usb:
    memorias_usb_mas_vendidos.append(producto_categorizado)
  elif producto_categorizado[1] == 0:
    memorias_usb_no_vendidos.append(producto_categorizado)
  else:
    memorias_usb_menos_vendidos.append(producto_categorizado)

#Pantallas
c_suma_ventas = 0
n_ventas = 0

pantallas_mas_vendidos = []
pantallas_menos_vendidos = []
pantallas_no_vendidos = []

for pantalla in c_pantallas:
  venta_actual = pantalla[1]
  c_suma_ventas += venta_actual
  if pantalla[1] != 0:
    n_ventas += 1

promedio_pantallas = c_suma_ventas / n_ventas

for producto_categorizado in c_pantallas:
  if producto_categorizado[1] >= promedio_pantallas:
    pantallas_mas_vendidos.append(producto_categorizado)
  elif producto_categorizado[1] == 0:
    pantallas_no_vendidos.append(producto_categorizado)
  else:
    pantallas_menos_vendidos.append(producto_categorizado)

#Bocinas
c_suma_ventas = 0
n_ventas = 0

bocinas_mas_vendidos = []
bocinas_menos_vendidos = []
bocinas_no_vendidos = []

for bocina in c_bocinas:
  venta_actual = bocina[1]
  c_suma_ventas += venta_actual
  if bocina[1] != 0:
    n_ventas += 1

promedio_bocinas = c_suma_ventas / n_ventas

for producto_categorizado in c_bocinas:
  if producto_categorizado[1] >= promedio_bocinas:
    bocinas_mas_vendidos.append(producto_categorizado)
  elif producto_categorizado[1] == 0:
    bocinas_no_vendidos.append(producto_categorizado)
  else:
    bocinas_menos_vendidos.append(producto_categorizado)

#Audífonos
c_suma_ventas = 0
n_ventas = 0

audifonos_mas_vendidos = []
audifonos_menos_vendidos = []
audifonos_no_vendidos = []

for audifono in c_audifonos:
  venta_actual = audifono[1]
  c_suma_ventas += venta_actual
  if audifono[1] != 0:
    n_ventas += 1

promedio_audifonos = c_suma_ventas / n_ventas

for producto_categorizado in c_audifonos:
  if producto_categorizado[1] >= promedio_audifonos:
    audifonos_mas_vendidos.append(producto_categorizado)
  elif producto_categorizado[1] == 0:
    audifonos_no_vendidos.append(producto_categorizado)
  else:
    audifonos_menos_vendidos.append(producto_categorizado)


#Lo siguiente se uso para calcular el total de productos por categoria para realizar en análisis de los productos no vendidos, sin embargo no se imprimieron los resultados en el código
total_procesadores = len(procesadores_no_vendidos + procesadores_mas_vendidos + procesadores_menos_vendidos)
total_tarjetas_video = len(tarjetas_video_no_vendidos + tarjetas_video_mas_vendidos + tarjetas_video_menos_vendidos)
total_tarjetas_madre = len(tarjetas_madre_no_vendidos + tarjetas_madre_mas_vendidos + tarjetas_madre_menos_vendidos)
total_discos_duros = len(discos_duros_no_vendidos + discos_duros_mas_vendidos + discos_duros_menos_vendidos)
total_memorias_usb = len(memorias_usb_no_vendidos + memorias_usb_mas_vendidos + memorias_usb_menos_vendidos)
total_pantallas = len(pantallas_no_vendidos + pantallas_mas_vendidos + pantallas_menos_vendidos)
total_bocinas = len(bocinas_no_vendidos + bocinas_mas_vendidos + bocinas_menos_vendidos)
total_audifonos = len(audifonos_no_vendidos + audifonos_mas_vendidos + audifonos_menos_vendidos)


#Ahora, para sacar las BUSQUEDAS por categoría
categorias = ["procesadores", "tarjetas de video", "tarjetas madre", "discos duros", "memorias usb", "pantallas", "bocinas", "audifonos"] #Lista con todas las categorías posibles

c_procesadores_busquedas =[] 
c_tarjetas_de_video_busquedas =[] 
c_tarjetas_madre_busquedas =[] 
c_discos_duros_busquedas = []
c_memorias_usb_busquedas = []
c_pantallas_busquedas =[] 
c_bocinas_busquedas =[] 
c_audifonos_busquedas =[] 

#División de todos los productos por categorías:
for product_searched in total_prods_buscados_ordenados:
  for product in lifestore_products:
    if product[0] == product_searched[0]: #Compara IDs
      categoria_actual = product[3] 
      if categoria_actual == "procesadores": #Verifica si la categoría corresponde o pasa al siguiente y así sucesivamente
        formato_ideal = [product[0], product_searched[1]] #Formato de ID, número de búsquedas totales del producto
        c_procesadores_busquedas.append(formato_ideal) #Agrega a la lista de la categoría correspondiente
      elif categoria_actual == "tarjetas de video":
        formato_ideal = [product[0], product_searched[1]]
        c_tarjetas_de_video_busquedas.append(formato_ideal)
      elif categoria_actual == "tarjetas madre":
        formato_ideal = [product[0], product_searched[1]]
        c_tarjetas_madre_busquedas.append(formato_ideal)
      elif categoria_actual == "discos duros":
        formato_ideal = [product[0], product_searched[1]]
        c_discos_duros_busquedas.append(formato_ideal)
      elif categoria_actual == "memorias usb":
        formato_ideal = [product[0], product_searched[1]]
        c_memorias_usb_busquedas.append(formato_ideal)
      elif categoria_actual == "pantallas":
        formato_ideal = [product[0], product_searched[1]]
        c_pantallas_busquedas.append(formato_ideal)
      elif categoria_actual == "bocinas":
        formato_ideal = [product[0], product_searched[1]]
        c_bocinas_busquedas.append(formato_ideal)
      else:
        formato_ideal = [product[0], product_searched[1]]
        c_audifonos_busquedas.append(formato_ideal)

#Siguiente paso: División de cada categoría en más, menos y no buscados
c_suma_busquedas = 0
n_busquedas = 0

#Listas de procesadores
procesadores_mas_busquedas = []
procesadores_menos_busquedas = []
procesadores_no_busquedas = []

#Sumo las busquedas y el total de productos en la categoría para poder sacar el promedio
for procesador in c_procesadores_busquedas:
  venta_actual = procesador[1]
  c_suma_busquedas += venta_actual
  if procesador[1] != 0: #Para el promedio excluyo los productos no buscados
    n_busquedas += 1

promedio_procesadores_busquedas = c_suma_busquedas / n_busquedas

for producto_categorizado in c_procesadores_busquedas:
  if producto_categorizado[1] >= promedio_procesadores_busquedas: #Verifico si es igual o superior al promedio
    procesadores_mas_busquedas.append(producto_categorizado)
  elif producto_categorizado[1] == 0: #Productos no vendidos
    procesadores_no_busquedas.append(producto_categorizado)
  else: #En caso de que sea inferior al promedio
    procesadores_menos_busquedas.append(producto_categorizado)

#Para todas las categorías siguientes se sigue el mismo procedimiento que arriba
c_suma_busquedas = 0 #Se resetean los dos contadores a 0
n_busquedas = 0

#Tarjetas de video
tarjetas_de_video_mas_busquedas = []
tarjetas_de_video_menos_busquedas = []
tarjetas_de_video_no_busquedas = []

for c_producto in c_tarjetas_de_video_busquedas:
  venta_actual = c_producto[1]
  c_suma_busquedas += venta_actual
  if c_producto[1] != 0: 
    n_busquedas += 1

promedio_tarjetas_de_video_busquedas = c_suma_busquedas / n_busquedas

for producto_categorizado in c_tarjetas_de_video_busquedas:
  if producto_categorizado[1] >= promedio_tarjetas_de_video_busquedas: 
    tarjetas_de_video_mas_busquedas.append(producto_categorizado)
  elif producto_categorizado[1] == 0: 
    tarjetas_de_video_no_busquedas.append(producto_categorizado)
  else: 
    tarjetas_de_video_menos_busquedas.append(producto_categorizado)

c_suma_busquedas = 0 
n_busquedas = 0

#Tarjetas madre
tarjetas_madre_mas_busquedas = []
tarjetas_madre_menos_busquedas = []
tarjetas_madre_no_busquedas = []

for c_producto in c_tarjetas_madre_busquedas:
  venta_actual = c_producto[1]
  c_suma_busquedas += venta_actual
  if c_producto[1] != 0: 
    n_busquedas += 1

promedio_tarjetas_madre_busquedas = c_suma_busquedas / n_busquedas

for producto_categorizado in c_tarjetas_madre_busquedas:
  if producto_categorizado[1] >= promedio_tarjetas_madre_busquedas: 
    tarjetas_madre_mas_busquedas.append(producto_categorizado)
  elif producto_categorizado[1] == 0: 
    tarjetas_madre_no_busquedas.append(producto_categorizado)
  else: 
    tarjetas_madre_menos_busquedas.append(producto_categorizado)

c_suma_busquedas = 0 
n_busquedas = 0

#Discos duros
discos_duros_mas_busquedas = []
discos_duros_menos_busquedas = []
discos_duros_no_busquedas = []

for c_producto in c_discos_duros_busquedas:
  venta_actual = c_producto[1]
  c_suma_busquedas += venta_actual
  if c_producto[1] != 0: 
    n_busquedas += 1

promedio_discos_duros_busquedas = c_suma_busquedas / n_busquedas

for producto_categorizado in c_discos_duros_busquedas:
  if producto_categorizado[1] >= promedio_discos_duros_busquedas: 
    discos_duros_mas_busquedas.append(producto_categorizado)
  elif producto_categorizado[1] == 0: 
    discos_duros_no_busquedas.append(producto_categorizado)
  else: 
    discos_duros_menos_busquedas.append(producto_categorizado)

c_suma_busquedas = 0 
n_busquedas = 0

#Memorias usb
memorias_usb_no_busquedas = []

#Como las memorias usb no tuvieron ninguna búsqueda solo se establece una lista para esta categoría
for producto_categorizado in c_memorias_usb_busquedas:
  if producto_categorizado[1] == 0: 
    memorias_usb_no_busquedas.append(producto_categorizado)

c_suma_busquedas = 0 
n_busquedas = 0

#Pantallas
pantallas_mas_busquedas = []
pantallas_menos_busquedas = []
pantallas_no_busquedas = []

for c_producto in c_pantallas_busquedas:
  venta_actual = c_producto[1]
  c_suma_busquedas += venta_actual
  if c_producto[1] != 0: 
    n_busquedas += 1

promedio_pantallas_busquedas = c_suma_busquedas / n_busquedas

for producto_categorizado in c_pantallas_busquedas:
  if producto_categorizado[1] >= promedio_pantallas_busquedas: 
    pantallas_mas_busquedas.append(producto_categorizado)
  elif producto_categorizado[1] == 0: 
    pantallas_no_busquedas.append(producto_categorizado)
  else: 
    pantallas_menos_busquedas.append(producto_categorizado)


c_suma_busquedas = 0 
n_busquedas = 0

#Bocinas
bocinas_mas_busquedas = []
bocinas_menos_busquedas = []
bocinas_no_busquedas = []

for c_producto in c_bocinas_busquedas:
  venta_actual = c_producto[1]
  c_suma_busquedas += venta_actual
  if c_producto[1] != 0: 
    n_busquedas += 1

promedio_bocinas_busquedas = c_suma_busquedas / n_busquedas

for producto_categorizado in c_bocinas_busquedas:
  if producto_categorizado[1] >= promedio_bocinas_busquedas: 
    bocinas_mas_busquedas.append(producto_categorizado)
  elif producto_categorizado[1] == 0: 
    bocinas_no_busquedas.append(producto_categorizado)
  else: 
    bocinas_menos_busquedas.append(producto_categorizado)

c_suma_busquedas = 0 
n_busquedas = 0

#Audifonos
audifonos_mas_busquedas = []
audifonos_menos_busquedas = []
audifonos_no_busquedas = []

for c_producto in c_audifonos_busquedas:
  venta_actual = c_producto[1]
  c_suma_busquedas += venta_actual
  if c_producto[1] != 0: 
    n_busquedas += 1

promedio_audifonos_busquedas = c_suma_busquedas / n_busquedas

for producto_categorizado in c_audifonos_busquedas:
  if producto_categorizado[1] >= promedio_audifonos_busquedas: 
    audifonos_mas_busquedas.append(producto_categorizado)
  elif producto_categorizado[1] == 0: 
    audifonos_no_busquedas.append(producto_categorizado)
  else: 
    audifonos_menos_busquedas.append(producto_categorizado)



#-----------------------------------------------------------------
#PRODUCTOS EVALUADOS POR SU RESEÑA EN EL SERVICIO Y PRODUCTOS DEVUELTOS
#Para sacar productos con mejores y peores reseñas

total_resenas = []
contador_ventas = 0 #Va contando las ventas
suma_resena = 0 #Suma el total de todas las reseñas

#Sacar los productos devueltos:
productos_devueltos = []
contador_devoluciones = 0

for producto in lifestore_products:
  for product_sold in lifestore_sales:
    if producto[0] == product_sold[1]: #Comprueba ID
      if product_sold[4] == 1: #Verifica que tenga devolución
        contador_devoluciones += 1
  if contador_devoluciones != 0: #Agrega a la lista solo los que tuvieron devolución
    formato_devoluciones = [producto[0], contador_devoluciones]
    productos_devueltos.append(formato_devoluciones)
    contador_devoluciones = 0


#Suma de total de las reseñas
for product in lifestore_products:
  for product_sold in lifestore_sales:
    if product[0]== product_sold[1]: #Comprueba ID
      contador_ventas += 1
      suma_resena += product_sold[2] #Suma el score (valor de reseña) del producto
  resenas_formato = [product[0], contador_ventas, suma_resena] #ID, ventas totales del producto, total de las reseñas del producto
  total_resenas.append(resenas_formato)
  suma_resena = 0
  contador_ventas = 0

lista_resena_promedios =[] #Nueva lista para reemplazar el total de las reseñas del producto por un promedio de las reseñas del mismo

#Promedio de reseñas
for resena in total_resenas:  
  if resena [1] != 0:
    promedio_resena = round(resena[2]/resena[1], 1) #Divide el total de reseñas entre el número de ventas y lo redondea a 1 decimal
    formato_id_resena = [resena[0], resena[1],promedio_resena]
    lista_resena_promedios.append(formato_id_resena)

#Ordenando la lista por reseña
lista_resena_ordenada = []

while lista_resena_promedios:
  minimo_resena = lista_resena_promedios [0][2]
  lista_actual_resena = lista_resena_promedios[0]
  for resena in lista_resena_promedios:
    if resena [2] < minimo_resena: #Compara si es menor al mínimo
      minimo_resena = resena [2] #Asigna nuevo mínimo
      lista_actual_resena = resena
  lista_resena_ordenada.append(lista_actual_resena) #Agrega a la nueva lista ordenada
  lista_resena_promedios.remove(lista_actual_resena) #Elimina de la lista anterior no ordenada

#Listas para dividir en mejores y peores reseñas
mejores_resenas = [] 
peores_resenas = []

#Se considerarán las mejores reseñas las que sean igual o arriba de 4
#Saco mejores y peores reseñas
for resena in lista_resena_ordenada:
  if resena[2] >= 4: #verifica que sea mayor o igual a 4
    mejores_resenas.append(resena) #agrega a la lista correspondiente
  else:
   peores_resenas.append(resena) #agrega a la lista correspondiente



#-----------------------------------------------------------------
#INGRESOS Y REPORTES MENSUALES
#Se cambió a 2020 el año de las ventas con ID 219 y 15 de los años 2002 y 2019 respectivamente 

#Lista con los meses y su número para poder clasificar las ventas
lista_meses = [[1, "Enero"], [2, "Febrero"], [3, "Marzo"], [4, "Abril"], [5, "Mayo"], [6, "Junio"], [7, "Julio"], [8, "Agosto"],[9, "Septiembre"], [10,"Octubre"], [11, "Noviembre"], [12, "Diciembre"]]

ventas_con_fechas = [] #Lista para almacenar el producto con la fecha de su venta
total_prod_vendidos_ingresos = [] #Lista para almacenar los ingresos

for product_sold in lifestore_sales:
  formato_fechas = [ int(product_sold[3][3:5]), product_sold[1]] #Formato: fecha solo con el mes (porque todos los años son el mismo), ID de producto
  ventas_con_fechas.append(formato_fechas)

ventas_con_fechas.sort() #Ordenamos la lista

#Listas para almacenar las ventas por mes
ventas_enero = []
ventas_febrero = []
ventas_marzo = []
ventas_abril = []
ventas_mayo = []
ventas_junio = []
ventas_julio = []
ventas_agosto = []
ventas_septiembre = []
ventas_octubre = []
ventas_noviembre = []
ventas_diciembre = []

for producto_fecha in ventas_con_fechas:
  if producto_fecha[0] == 1: #Asigna el producto a la lista correspondiente dependiendo del mes en el que se vendió
    ventas_enero.append(producto_fecha)
  elif producto_fecha[0] == 2:
    ventas_febrero.append(producto_fecha)
  elif producto_fecha[0] == 3:
    ventas_marzo.append(producto_fecha)
  elif producto_fecha[0] == 4:
    ventas_abril.append(producto_fecha)
  elif producto_fecha[0] == 5:
    ventas_mayo.append(producto_fecha)
  elif producto_fecha[0] == 6:
    ventas_junio.append(producto_fecha)
  elif producto_fecha[0] == 7:
    ventas_julio.append(producto_fecha)
  elif producto_fecha[0] == 8:
    ventas_agosto.append(producto_fecha)
  elif producto_fecha[0] == 9:
    ventas_septiembre.append(producto_fecha)
  elif producto_fecha[0] == 10:
    ventas_octubre.append(producto_fecha)
  elif producto_fecha[0] == 11:
    ventas_noviembre.append(producto_fecha)
  elif producto_fecha[0] == 12:
    ventas_diciembre.append(producto_fecha)

#Para ver cuántas ventas hubo por mes:
elementos_en_meses = [[1,len(ventas_enero)],[2,len(ventas_febrero)],[3,len(ventas_marzo)],[4,len(ventas_abril)],[5,len(ventas_mayo)],[6,len(ventas_junio)],[7,len(ventas_julio)],[8,len(ventas_agosto)],[9,len(ventas_septiembre)],[10,len(ventas_octubre)],[11,len(ventas_noviembre)],[12,len(ventas_diciembre)]]

#Variables para ir sumando los ignresos por mes
ingresos_enero = 0
ingresos_febrero = 0
ingresos_marzo = 0
ingresos_abril = 0
ingresos_mayo = 0
ingresos_junio = 0
ingresos_julio = 0
ingresos_agosto = 0
ingresos_septiembre = 0
ingresos_octubre = 0
ingresos_noviembre = 0
ingresos_diciembre = 0

ingreso_por_venta = 0 #Contador de ingresos

for venta in ventas_enero:
  for product in lifestore_products:
    if venta [1] == product[0]: #Compara IDs
      ingreso_por_venta = product[2] #Especifica el precio del producto
      ingresos_enero += ingreso_por_venta #Suma el ingreso de la venta al total del mes
  ingreso_por_venta = 0  #Reset del contador

#Los ingresos de los siguientes meses se calculan igual que el anterior
for venta in ventas_febrero:
  for product in lifestore_products:
    if venta [1] == product[0]:
      ingreso_por_venta = product[2]
      ingresos_febrero += ingreso_por_venta
  ingreso_por_venta = 0  

for venta in ventas_marzo:
  for product in lifestore_products:
    if venta [1] == product[0]:
      ingreso_por_venta = product[2]
      ingresos_marzo += ingreso_por_venta
  ingreso_por_venta = 0  

for venta in ventas_abril:
  for product in lifestore_products:
    if venta [1] == product[0]:
      ingreso_por_venta = product[2]
      ingresos_abril += ingreso_por_venta
  ingreso_por_venta = 0  

for venta in ventas_mayo:
  for product in lifestore_products:
    if venta [1] == product[0]:
      ingreso_por_venta = product[2]
      ingresos_mayo += ingreso_por_venta
  ingreso_por_venta = 0  

for venta in ventas_junio:
  for product in lifestore_products:
    if venta [1] == product[0]:
      ingreso_por_venta = product[2]
      ingresos_junio += ingreso_por_venta
  ingreso_por_venta = 0  

for venta in ventas_julio:
  for product in lifestore_products:
    if venta [1] == product[0]:
      ingreso_por_venta = product[2]
      ingresos_julio += ingreso_por_venta
  ingreso_por_venta = 0  

for venta in ventas_agosto:
  for product in lifestore_products:
    if venta [1] == product[0]:
      ingreso_por_venta = product[2]
      ingresos_agosto += ingreso_por_venta
  ingreso_por_venta = 0

for venta in ventas_septiembre:
  for product in lifestore_products:
    if venta [1] == product[0]:
      ingreso_por_venta = product[2]
      ingresos_septiembre += ingreso_por_venta
  ingreso_por_venta = 0  

for venta in ventas_octubre:
  for product in lifestore_products:
    if venta [1] == product[0]:
      ingreso_por_venta = product[2]
      ingresos_octubre += ingreso_por_venta
  ingreso_por_venta = 0  

for venta in ventas_noviembre:
  for product in lifestore_products:
    if venta [1] == product[0]:
      ingreso_por_venta = product[2]
      ingresos_noviembre += ingreso_por_venta
  ingreso_por_venta = 0  

for venta in ventas_diciembre:
  for product in lifestore_products:
    if venta [1] == product[0]:
      ingreso_por_venta = product[2]
      ingresos_diciembre += ingreso_por_venta
  ingreso_por_venta = 0  

#Sacar total de ingresos anuales y promedio de los ingresos mensuales:
ingresos_anuales = ingresos_enero + ingresos_febrero + ingresos_marzo + ingresos_abril + ingresos_mayo + ingresos_junio + ingresos_julio + ingresos_agosto + ingresos_septiembre + ingresos_octubre + ingresos_noviembre + ingresos_diciembre #suma los ingresos de cada mes

ventas_promedio_mensuales = round(ingresos_anuales/12,0) #Divide el total entre el numero de meses



#-----------------------------------------------------------------
#ÁREA DE LOGIN

print("Bienvenido,\nPor favor ingresa tu nombre de usuario y contraseña")

#El administrador ingresa su nombre de usuario que es "Administrador" con contraseña "lifestore1" o "Usuario invitado" con contraseña "invitado0"

nombre_usuario = input("\nNombre de usuario: ") #Pide el nombre de usuario

#es_admin va a funcionar como bandera para mostrarle al Administrador lo que él puede ver
es_admin = 0
limite_de_intentos = 0 #Contador para evitar el exceso de intentos al ingresar las contraseñas

#Ingreso de los usuarios:
while nombre_usuario != "Administrador" and nombre_usuario != "Usuario invitado": #verifica que el nombre de usuario sea válido
 print("\nUsuario incorrecto, por favor intenta nuevamente")
 nombre_usuario = input("Nombre de usuario: ")

#Acceso de administrador:
if nombre_usuario == "Administrador":
  contraseña_administrador = input("Ingresa tu contraseña: ")#Pide la contraseña

  while contraseña_administrador != "lifestore1" and limite_de_intentos < 5: #Limita el ingreso de contraseña a 5 intentos

    print("\nContraseña incorrecta, por favor intenta de nuevamente")

    limite_de_intentos += 1 #va sumando el # de intentos que lleva el usuario
    limite_intentos_para_texto = 5 - limite_de_intentos #Conversión para mostrar el número en el mensaje
    limite_de_intentos_texto = str(limite_intentos_para_texto)

    print("\nTe quedan únicamente " + limite_de_intentos_texto + " intentos") #Muestra el número de intentos que le quedan al usuario

    contraseña_administrador = input("Ingresa tu contraseña: ")#Vuelve a pedir la contraseña

  if limite_de_intentos >= 5: #Si se pasa del límite de intentos
    print("\nHas excedido el número de intentos, por favor prueba más tarde")
   
  if contraseña_administrador == "lifestore1":
    es_admin = 1 #Si ingresa la contraseña correcta la bandera cambia a 1 para mostrarle al administrador lo correspondiente

#Acceso de usuario invitado:
elif nombre_usuario == "Usuario invitado":
  contraseña_usuario_invitado = input("Ingresa tu contraseña: ")#Pide la contraseña

  while contraseña_usuario_invitado != "invitado0" and limite_de_intentos < 5: #Limita el ingreso de contraseña a 5 intentos

    print("\nContraseña incorrecta, por favor intenta de nuevamente")

    limite_de_intentos += 1 #va sumando el # de intentos que lleva el usuario
    limite_intentos_para_texto = 5 - limite_de_intentos #Conversión para mostrar el número en el mensaje
    limite_de_intentos_texto = str(limite_intentos_para_texto)

    print("\nTe quedan únicamente " + limite_de_intentos_texto + " intentos") #Muestra el número de intentos que le quedan al usuario

    contraseña_usuario_invitado = input("\n Ingresa tu contraseña: ")#Vuelve a pedir la contraseña

  if limite_de_intentos >= 5: #Si se pasa del límite de intentos
    print("\n Has excedido el número de intentos, por favor prueba más tarde")
  
  print("\nUsted ha ingresado como usuario invitado, no es posible ver los reportes de ventas y búsquedas.") #Si ingresa la contraseña correcta se le muestra este mensaje, el usuario invitado no tiene acceso a la información del administrador

#-----------------------------------------------------------------
#ÁREA DE ADMINISTRADOR

opcion_elegida = 0 #Bandera para poder regresar al menú anterior y salir del menú principal
#Lo siguiente se mostrará al administrador:
if es_admin == 1:
  print("\nBienvenido, Administrador\n")
  while opcion_elegida != "s": #cuando sea = "s" sale del menú
    print("¿Qué deseas hacer?\n\n1- Mostrar los productos más y menos vendidos y buscados\n2- Mostrar los productos por reseña en el servicio\n3- Mostrar el resumen de las ventas (ingresos y desglose mensual)\n")
    print("Presiona s para salir")
    opcion_elegida = input("\nElige una opción (1/2/3 o s para salir): ")#El Admin ingresa la opción que quiere ver
    if opcion_elegida == "1": #Muestra los productos más y menos vendidos
      while opcion_elegida != "r":
        print("\n¿Qué deseas ver?\n\n1.1- Mostrar el listado general de los productos más vendidos y los productos más buscados\n1.2- Mostrar los productos más vendidos y los productos más buscados por categoría\n1.3- Mostrar el listado general de los productos menos vendidos y los menos buscados\n1.4- Mostrar los productos menos vendidos y los menos buscados por categoría así como información de productos no vendidos por categoría\n1.5 Mostrar el listado de productos devueltos\n\nPresiona r para regresar al menú inicial")
        opcion_elegida = input("\nElige una opción (1.1 / 1.2 / 1.3 / 1.4 / 1.5 o r para regresar): ")#El Admin ingresa la opción que quiere ver
        if opcion_elegida == "1.1":
          print("\nElegiste la opción 1.1\n")
          print("\nEl promedio de búsquedas fue de ", round(promedio_busquedas,1))
          print("\nPor encontrarse arriba del promedio, los productos más buscados fueron: ")
          for producto in productos_mas_buscados:
            for product in lifestore_products:
              if product[0] == producto[0]: #Compara IDs
                print("El producto ", product[1], " se buscó ", producto[1], "veces\n") #Muestra el nombre del producto y el numero de veces que se buscó
          print("\nEl promedio de ventas fue de ", round(promedio_ventas,1))
          print("\nPor encontrarse arriba del promedio, los productos más vendidos fueron: ")
          for producto in productos_mas_vendidos:
            for product in lifestore_products:
              if product[0] == producto[0]: #Compara IDs
                print("El producto ", product[1], " se vendió ", producto[1], "veces\n") #Muestra el nombre del producto y el numero de veces que se vendió
        elif opcion_elegida == "1.2":
          print("\nElegiste la opción 1.2") #Muestra la división por categorías de productos mas vendidos y buscados

          print("\nLos procesadores más vendidos fueron: \n")
          for procesador in procesadores_mas_vendidos:
            for product in lifestore_products:
              if procesador[0] == product [0]: #Compara IDs
                print("El ", product[1], " se vendió ", procesador[1], " veces") #Imprime el número de veces que se vendió cada producto

          print("\nLas tarjetas de video más vendidas fueron: \n") #El proceso de los productos siguientes es igual que el anterior
          for tarjeta_video in tarjetas_video_mas_vendidos:
            for product in lifestore_products:
             if tarjeta_video[0] == product [0]:
                print("La ", product[1], " se vendió ", tarjeta_video[1], " veces")

          print("\nLas tarjetas madre más vendidas fueron: \n")
          for tarjeta_madre in tarjetas_madre_mas_vendidos:
            for product in lifestore_products:
             if tarjeta_madre[0] == product [0]:
                print("La ", product[1], " se vendió ", tarjeta_madre[1], " veces")

          print("\nLos discos duros más vendidos fueron: \n")
          for disco_duro in discos_duros_mas_vendidos:
            for product in lifestore_products:
              if disco_duro[0] == product [0]:
                print("El ", product[1], " se vendió ", disco_duro[1], " veces")

          print("\nLas memorias usb más vendidas fueron: \n")
          for memoria_usb in memorias_usb_mas_vendidos:
            for product in lifestore_products:
              if memoria_usb[0] == product [0]:
                print("La ", product[1], " se vendió ", memoria_usb[1], " veces")

          print("\nLas pantallas más vendidas fueron: \n")
          for pantalla in pantallas_mas_vendidos:
            for product in lifestore_products:
              if pantalla[0] == product [0]:
                print("El ", product[1], " se vendió ", pantalla[1], " veces")

          print("\nLas bocinas más vendidas fueron: \n")
          for bocina in bocinas_mas_vendidos:
            for product in lifestore_products:
              if bocina[0] == product [0]:
                print("Las ", product[1], " se vendieron ", bocina[1], " veces")

          print("\nLos audífonos más vendidos fueron: \n")
          for audifono in audifonos_mas_vendidos:
            for product in lifestore_products:
              if audifono[0] == product [0]:
                print("Los ", product[1], " se vendieron ", audifono[1], " veces") 

          print("\nLos procesadores más buscados fueron: \n") #Comienza a mostrar los más buscados
          for procesador in procesadores_mas_busquedas:
            for product in lifestore_products:
              if procesador[0] == product [0]: #Compara IDs
                print("El ", product[1], " se buscó ", procesador[1], " veces") #Muestra el número de veces que el producto se buscó

          print("\nLas tarjetas de video más buscadas fueron: \n")
          for tarjeta_video in tarjetas_de_video_mas_busquedas:
            for product in lifestore_products:
             if tarjeta_video[0] == product [0]:
                print("La ", product[1], " se buscó ", tarjeta_video[1], " veces")

          print("\nLas tarjetas madre más buscadas fueron: \n")
          for tarjeta_madre in tarjetas_madre_mas_busquedas:
            for product in lifestore_products:
             if tarjeta_madre[0] == product [0]:
                print("La ", product[1], " se buscó ", tarjeta_madre[1], " veces")

          print("\nLos discos duros más buscados fueron: \n")
          for disco_duro in discos_duros_mas_busquedas:
            for product in lifestore_products:
              if disco_duro[0] == product [0]:
                print("El ", product[1], " se buscó ", disco_duro[1], " veces")

          print("\nLas memorias usb no figuran en las listas de búsquedas \n")

          print("\nLas pantallas más buscadas fueron: \n")
          for pantalla in pantallas_mas_busquedas:
            for product in lifestore_products:
              if pantalla[0] == product [0]:
                print("El ", product[1], " se buscó ", pantalla[1], " veces")

          print("\nLas bocinas más buscadas fueron: \n")
          for bocina in bocinas_mas_busquedas:
            for product in lifestore_products:
              if bocina[0] == product [0]:
                print("Las ", product[1], " se buscaron ", bocina[1], " veces")

          print("\nLos audífonos más buscadas fueron: \n")
          for audifono in audifonos_mas_busquedas:
            for product in lifestore_products:
              if audifono[0] == product [0]:
                print("Los ", product[1], " se buscaron ", audifono[1], " veces")                

          print("\nEl total de búsquedas por categoría es:\n") #Muestra el resumen de búsquedas por categoría
          for categoria in categorias:
            busquedas_total=0 #Contador de busquedas
            for producto in lifestore_products:
              for search in lifestore_searches:
                if search[1]==producto[0] and producto[3]==categoria: #Compara id y categoría en la lista de productos con la lista de categorias
                  busquedas_total+=1
            print("Categoría: ",categoria, " Búsquedas: ",busquedas_total)

          print("\nEl total de ventas por categoría es:\n") #Muestra el resumen de ventas por categoría
          for categoria in categorias:
            ventas_total=0 #Contador de ventas
            for producto in lifestore_products:
              for sale in lifestore_sales:
                if sale[1]==producto[0] and producto[3]==categoria: #Compara id y categoría en la lista de productos con la lista de categorias
                  ventas_total+=1
            print("Categoría: ",categoria, " Ventas: ",ventas_total)


        elif opcion_elegida == "1.3": #Va a mostrar los productos menos buscados y vendidos
          print("\nElegiste la opción 1.3")
          print("\nLos productos menos buscados fueron:\n")
          for producto in productos_menos_buscados:
            for product in lifestore_products:
              if producto[0] == product[0]: #Compara IDs
                print("El producto ", product[1], " se buscó ", producto[1], "veces") #Muestra el número de veces que se buscó
          print("\nLos productos menos vendidos fueron:\n") #Primera lista de productos menos vendidos
          for producto in productos_menos_vendidos:
            for product in lifestore_products:
              if producto[0] == product[0]:#Compara IDs
                print("El producto ", product[1], " se vendió ", producto[1], "veces")

          print("\nLos productos que no se vendieron fueron:\n") #Esta tercera lista es de los productos que no se vendieron
          for producto_no_vendido in productos_rezagados:
            for product in lifestore_products:
              if product[0] == producto_no_vendido[0]:#Compara IDs
                print(product[1])

          print("\nLos productos que no se buscaron fueron los siguientes:\n") #Muestra los productos no buscados
          for producto_no_buscado in productos_no_buscados:
            for product in lifestore_products:
              if product[0] == producto_no_buscado[0]:#Compara IDs
                print(product[1])

        elif opcion_elegida == "1.4": #Muestra las menores búsquedas y ventas y los productos no buscados o vendidos por categoría
          print("\nElegiste la opción 1.4")

          print("\nStock de los productos no vendidos:\n")
          #Stock de productos no vendidos
          for producto in productos_rezagados:
            for product in lifestore_products:
                if producto[0] == product [0]: #Compara IDs
                  print("El stock del producto", product[1], " es de ",product[4])
          print("\nNúmero de búsquedas de los productos no vendidos:\n")
          #Búsquedas de broductos no vendidos
          for product in productos_rezagados:
            for product_searched in total_prods_buscados_ordenados:
              if product[0] == product_searched[0]: #Compara Ids
                print("\nEl producto ", product[0], " fue buscado ", product_searched[1], " veces")

          print("\n\nProcesadores:")
          print("\nLos procesadores menos vendidos fueron: \n")
          for procesador in procesadores_menos_vendidos:
            for product in lifestore_products:
              if procesador[0] == product [0]:#Compara Ids
                print("El ", product[1], " solamente se vendió ", procesador[1], " veces")

          print("\nLos procesadores no vendidos fueron: \n")
          for producto_no_vendido in procesadores_no_vendidos:
            for product in lifestore_products:
              if product[0] == producto_no_vendido[0]:
                print(product[1]) 

          print("\n\nTarjetas de video:")
          print("\nLas tarjetas de video menos vendidas fueron: \n")
          for tarjeta_video in tarjetas_video_menos_vendidos:
            for product in lifestore_products:
             if tarjeta_video[0] == product [0]:
                print("La ", product[1], " solamente se vendió ", tarjeta_video[1], " veces")

          print("\nLas tarjetas de video no vendidas fueron: \n")
          for producto_no_vendido in tarjetas_video_no_vendidos:
            for product in lifestore_products:
              if product[0] == producto_no_vendido[0]:
                print(product[1])  

          print("\n\nTarjetas madre:")
          print("\nLas tarjetas madre menos vendidas fueron: \n")
          for tarjeta_madre in tarjetas_madre_menos_vendidos:
            for product in lifestore_products:
             if tarjeta_madre[0] == product [0]:
                print("La ", product[1], " solamente se vendió ", tarjeta_madre[1], " veces")

          print("\nLas tarjetas madre no vendidas fueron: \n")
          for producto_no_vendido in tarjetas_madre_no_vendidos:
            for product in lifestore_products:
              if product[0] == producto_no_vendido[0]:
                print(product[1])            

          print("\n\nDiscos duros:")
          print("\nLos discos duros menos vendidos fueron: \n")
          for disco_duro in discos_duros_menos_vendidos:
            for product in lifestore_products:
              if disco_duro[0] == product [0]:
                print("El ", product[1], " solamente se vendió ", disco_duro[1], " veces")

          print("\nLos discos duros no vendidos fueron:\n")
          for producto_no_vendido in discos_duros_no_vendidos:
            for product in lifestore_products:
              if product[0] == producto_no_vendido[0]:
                print(product[1])            

          print("\n\nMemorias usb:")
          print("\nDebido a la baja cantidad de ventas e inventario en la categoría de memorias usb, no hay productos que entren en el rango de menos vendidas\n")

          print("\nLas memorias usb no vendidas fueron:\n")
          for producto_no_vendido in memorias_usb_no_vendidos:
            for product in lifestore_products:
              if product[0] == producto_no_vendido[0]:
                print(product[1])           

          print("\n\nPantallas:")
          print("\nDebido a la baja cantidad de ventas en la categoría de pantallas, no hay productos que entren en el rango de menos vendidas\n")

          print("\nLas pantallas no vendidas fueron: \n")
          for producto_no_vendido in pantallas_no_vendidos:
            for product in lifestore_products:
              if product[0] == producto_no_vendido[0]:
                print(product[1])             

          print("\n\nBocinas:")
          print("\nDebido a la baja cantidad de ventas en la categoría de bocinas, no hay productos que entren en el rango de menos vendidas\n")

          print("\nLas bocinas no vendidas fueron: \n")
          for producto_no_vendido in bocinas_no_vendidos:
            for product in lifestore_products:
              if product[0] == producto_no_vendido[0]:
                print(product[1])           

          print("\n\nAudífonos:")
          print("\nLos audífonos menos vendidos fueron: \n")
          for audifono in audifonos_menos_vendidos:
            for product in lifestore_products:
              if audifono[0] == product[0]:
                print("Los ", product[1], " solamente se vendieron ", audifono[1], " veces")

          print("\nLos audífonos no vendidos fueron: \n")
          for producto_no_vendido in audifonos_no_vendidos:
            for product in lifestore_products:
              if product[0] == producto_no_vendido[0]:
                print(product[1])

          print("\nProductos menos buscados y no buscados: \n\nProcesadores:")#A partir de aquí muestra las búsquedas
          print("\nLos procesadores menos buscados fueron: \n")
          for procesador in procesadores_menos_busquedas:
            for product in lifestore_products:
              if procesador[0] == product [0]:
                print("El ", product[1], " solamente se buscó ", procesador[1], " veces")

          print("\nLos procesadores no buscados fueron: \n")
          for producto_no_busquedas in procesadores_no_busquedas:
            for product in lifestore_products:
              if product[0] == producto_no_busquedas[0]:
                print(product[1]) 

          print("\n\nTarjetas de video:")
          print("\nLas tarjetas de video menos buscadas fueron: \n")
          for tarjeta_video in tarjetas_de_video_menos_busquedas:
            for product in lifestore_products:
             if tarjeta_video[0] == product [0]:
                print("La ", product[1], " solamente se buscó ", tarjeta_video[1], " veces")

          print("\nLas tarjetas de video no buscadas fueron: \n")
          for producto_no_busquedas in tarjetas_de_video_no_busquedas:
            for product in lifestore_products:
              if product[0] == producto_no_busquedas[0]:
                print(product[1])  

          print("\n\nTarjetas madre:")
          print("\nLas tarjetas madre menos buscadas fueron: \n")
          for tarjeta_madre in tarjetas_madre_menos_busquedas:
            for product in lifestore_products:
             if tarjeta_madre[0] == product [0]:
                print("La ", product[1], " solamente se buscó ", tarjeta_madre[1], " veces")

          print("\nLas tarjetas madre no buscadas fueron: \n")
          for producto_no_busquedas in tarjetas_madre_no_busquedas:
            for product in lifestore_products:
              if product[0] == producto_no_busquedas[0]:
                print(product[1])            

          print("\n\nDiscos duros:")
          print("\nLos discos duros menos buscados fueron: \n")
          for disco_duro in discos_duros_menos_busquedas:
            for product in lifestore_products:
              if disco_duro[0] == product [0]:
                print("El ", product[1], " solamente se buscó ", disco_duro[1], " veces")

          print("\nLos discos duros no buscados fueron:\n")
          for producto_no_busquedas in discos_duros_no_busquedas:
            for product in lifestore_products:
              if product[0] == producto_no_busquedas[0]:
                print(product[1])            

          print("\n\nMemorias usb:")
          print("\nDebido a la baja cantidad de ventas e inventario en la categoría de memorias usb, no hay productos que entren en el rango de menores buscadas\n")

          print("\nLas memorias usb no buscadas fueron:\n")
          for producto_no_busquedas in memorias_usb_no_busquedas:
            for product in lifestore_products:
              if product[0] == producto_no_busquedas[0]:
                print(product[1])           

          print("\n\nPantallas:")
          print("\nLas pantallas menos buscadas fueron: \n")
          for producto_busquedas in pantallas_menos_busquedas:
            for product in lifestore_products:
              if product[0] == producto_busquedas[0]:
                print("El ", product[1], " solamente se buscó ", producto_busquedas[1], " veces") 

          print("\nLas pantallas no buscadas fueron: \n")
          for producto_no_busquedas in pantallas_no_busquedas:
            for product in lifestore_products:
              if product[0] == producto_no_busquedas[0]:
                print(product[1])             

          print("\n\nBocinas:")
          print("\nLas bocinas menos buscadas fueron: \n")
          for producto_busquedas in pantallas_menos_busquedas:
            for product in lifestore_products:
              if product[0] == producto_busquedas[0]:
                print("Los ", product[1], " solamente se buscaron ", producto_busquedas[1], " veces") 

          print("\nLas bocinas no buscadas fueron: \n")
          for producto_no_busquedas in bocinas_no_busquedas:
            for product in lifestore_products:
              if product[0] == producto_no_busquedas[0]:
                print(product[1])           

          print("\n\nAudífonos:")
          print("\nLos audífonos menos buscados fueron: \n")
          for audifono in audifonos_menos_busquedas:
            for product in lifestore_products:
              if audifono[0] == product[0]:
                print("Los ", product[1], " solamente se buscaron ", audifono[1], " veces")

          print("\nLos audífonos no buscados fueron: \n")
          for producto_no_busquedas in audifonos_no_busquedas:
            for product in lifestore_products:
              if product[0] == producto_no_busquedas[0]:
                print(product[1]) #Fin del punto 1.4               

        elif opcion_elegida == "1.5": #Muestra los productos devueltos
          print("\nElegiste la opción 1.5")
          print("\nLos productos devueltos fueron los siguientes:\n")

          for product in lifestore_products:
            for producto_devuelto in productos_devueltos:
              if producto_devuelto[0] == product[0]: #Compara IDs
                print("El producto ", product[1]," de la categoría de ", product[3]," fue devuelto", producto_devuelto[1]," veces\n")

          print("\nLa categoría con más devoluciones fue la de tarjetas madre con un total de 6 productos devueltos")
        elif opcion_elegida == "r": #Para regresar al menu principal
          continue
        else:
          print("Opción no válida, por favor intenta de nuevo")
          opcion_elegida = input("\nElige una opción (1.1 / 1.2 / 1.3 / 1.4 / 1.5 o r para regresar): ")  #Pide ingresar nuevamente la opción
    elif opcion_elegida == "2":
      while opcion_elegida != "r":
        print("\n¿Qué deseas ver?\n\n2.1 Mostrar todos los productos ordenados según su puntaje de reseña\n2.2 Mostrar los productos con mejores reseñas\n2.3 Mostrar los productos con peores reseñas\n Presiona r para regresar")
        opcion_elegida = input ("\nElige una opción (2.1 / 2.2 / 2.3 o r para regresar): ")
        if opcion_elegida == "2.1":
          print("\nElegiste la opción 2.1")          
          print("\nA continuación se mostrarán todos los productos ordenados según su puntaje de reseña de manera ascendente\n")
          for resena in lista_resena_ordenada:
            for product in lifestore_products:
              if resena[0] == product [0]: #Compara IDs
                print("\nEl producto ", product [1], " con un total de ", resena[1], " ventas, obtuvo un promedio de reseñas de ", resena[2])
        elif opcion_elegida ==  "2.2": #Muestra solo las mejores reseñas
          print("\nElegiste la opción 2.2")          
          print("Los productos con mejores reseñas fueron los siguientes: \n")
          for resena in mejores_resenas:
            for product in lifestore_products:
              if resena[0] == product [0]:
                print("El producto ", product[1],  ", el cual se vendió ", resena[1], " veces, tiene un promedio de reseñas de ", resena[2])
        elif opcion_elegida == "2.3": #Muestra las peores reseñas
          print("\nElegiste la opción 2.3")          
          print("\nLos productos con peores reseñas fueron los siguientes: \n")
          for resena in peores_resenas:
            for product in lifestore_products:
              if resena[0] == product [0]:
                print("El producto ", product[1], ", el cual se vendió ", resena[1], " veces, tiene un promedio de reseñas de ", resena[2])
        elif opcion_elegida == "r": #Permite regresar al menu principal
          continue
        else:
          print("\nOpción no válida, por favor intenta de nuevo")
          opcion_elegida = input ("\nElige una opción (2.1 / 2.2 / 2.3 o r para regresar): ") #Pide la opción de nuevo en caso de equivocarse
    elif opcion_elegida == "3": #Muestra el resumen de ventas e ingresos
       while opcion_elegida != "r":
          print ("\nHas elegido la opción 3")
          print ("\n¿Qué deseas ver?\n3.1 Ingresos y ventas por mes\n3.2 Ingresos anuales y promedio de venta mensual\n Presiona r para regresar al menú principal")
          opcion_elegida = input("\nElige una opción (3.1 / 3.2 o r para regresar): ") #Pide al Admin seleccionar una opción
          if opcion_elegida == "3.1":
            print ("\nHas elegido la opción 3.1")  
            print ("\nEl número de ventas por mes fue el siguiente: ")      
            for mes in lista_meses:
              for elemento in elementos_en_meses:
                if mes[0]== elemento [0]: #Compara el numero de mes (ej. 1 para enero)
                  print(mes[1], elemento[1]) #Imprime el nombre del mes y el numero de ventas en ese mes

            print("\nLos ingresos mensuales fueron los siguientes:")
            print("Enero ", ingresos_enero)
            print("Febrero ",ingresos_febrero)
            print("Marzo ",ingresos_marzo)
            print("Abril ", ingresos_abril)
            print("Mayo ",ingresos_mayo)
            print("Junio ",ingresos_junio)
            print("Julio ",ingresos_julio)
            print("Agosto ",ingresos_agosto)
            print("Septiembre ",ingresos_septiembre)
            print("Octubre ",ingresos_octubre)
            print("Noviembre ",ingresos_noviembre)
            print("Diciembre ",ingresos_diciembre)

            print("\nEl mes con más ventas e ingresos fue abril\nLos meses con menos ventas y menos ingresos fueron agosto, septiembre y noviembre\nLos meses sin ventas ni ingresos fueron octubre y diciembre")
          elif opcion_elegida == "3.2":
            print ("\nHas elegido la opción 3.2") 
            print("\nLos ingresos para el 2020 fueron de ", ingresos_anuales, "pesos")
            print("\nLas ventas promedio mensuales fueron de ", ventas_promedio_mensuales, " pesos")
          elif opcion_elegida == "s": #"s" permite salir del menú
            continue
          else:
            print("\nOpción no válida, por favor intenta de nuevo")
            opcion_elegida = input("Elige una opción (3.1 / 3.2 o r para regresar): ") #Pide nuevamente la opci'on en caso de que sea incorrecta
    elif opcion_elegida == "s": #"s" permite salir del menú
      continue
    else:
      print("\nOpción no válida, por favor intenta de nuevo")
      opcion_elegida = input("\nElige una opción (1/2/3 o s para salir): ") #Pide nuevamente la opci'on en caso de que sea incorrecta

print("Has salido del sistema") #Mensaje cuando se presiona s y se sale del menú
